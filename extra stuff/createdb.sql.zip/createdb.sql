-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 16, 2014 at 05:55 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `createdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `appscheduler_bookings`
--

CREATE TABLE IF NOT EXISTS `appscheduler_bookings` (
  `student_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `student_name` varchar(255) DEFAULT NULL,
  `student_email` varchar(255) DEFAULT NULL,
  `student_phone` varchar(255) DEFAULT NULL,
  `student_city` varchar(255) DEFAULT NULL,
  `student_state` varchar(255) DEFAULT NULL,
  `student_zip` varchar(255) DEFAULT NULL,
  `student_add1` varchar(255) DEFAULT NULL,
  `student_add2` varchar(255) DEFAULT NULL,
  `student_notes` text,
  `student_dob` date DEFAULT NULL,
  `student_mis` varchar(255) DEFAULT NULL,
  `appointment_id` int(10) unsigned DEFAULT NULL,
  `appointment_d` date DEFAULT NULL,
  `appointment_t` time DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13225 ;

--
-- Dumping data for table `appscheduler_bookings`
--

INSERT INTO `appscheduler_bookings` (`student_id`, `student_name`, `student_email`, `student_phone`, `student_city`, `student_state`, `student_zip`, `student_add1`, `student_add2`, `student_notes`, `student_dob`, `student_mis`, `appointment_id`, `appointment_d`, `appointment_t`) VALUES
(11111, 'Harshal Shah', 'harshal_shah93@yahoo.com', '5625072049', 'LongBeach', 'California', '90815', 'Garford Street', '', 'Appointment for consulting', '1993-05-26', 'hhh', 11111, '2014-12-05', '09:00:00'),
(11112, 'Nilay Shah', 'phpcsulbtest@gmail.com', '5625072049', 'Fullerton', 'California', '90815', 'Garford Street', '', 'Appointment for body checkup.', '1994-05-24', 'hhh', 11112, '2014-12-12', '09:00:00'),
(11113, 'Kalgi Jani', 'phpcsulbtest@gmail.com', '5625072049', 'Dallas', 'Texas', '34567', 'Mc Villiam Strret', '', 'Appointment for consulting', '2014-10-18', 'hhh', 11113, '2014-12-07', '10:00:00'),
(11114, 'Shaishav Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '90815', '5050 E Garford Street', 'Apt#4', 'For regular check up.', '1992-12-03', 'hhh', 11114, '2014-01-09', '10:00:00'),
(11116, 'Jay Nayak', 'hs26593@gmail.com', '5625072049', 'NewYork', 'NewYork', '90234', 'Mc Villiam Strret', '', 'check up for skin problem.', '2004-12-11', 'hhh', 11116, '2014-01-14', '04:00:00'),
(11119, 'Dhruvesh Shah', 'hs26593@gmail.com', '5625072049', 'Houston', 'Texas', '56790', 'Mc Villiam Strret', '', 'appointment for Diabetis Test', '2002-08-10', 'hhh', 11119, '2014-03-19', '05:00:00'),
(11120, 'Akash Shah', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'Oregon', '34567', 'Garford Street', '', 'Appointment for clinical analysis', '1984-01-30', 'hhh', 11120, '2014-06-20', '06:00:00'),
(11124, 'Prakruti Bhadja', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '90815', 'Beverly Plaza', 'Clark Avenue', 'Appointment for regular check up.', '2002-07-24', 'hhh', 11124, '2014-12-27', '03:00:00'),
(11125, 'Vidit Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Fullerton', 'California', '39485', 'Clark Avenue', '', 'Appointment for regular check up', '1997-12-27', 'hhh', 11125, '2014-01-23', '03:00:00'),
(11126, 'Pratiksha Carpenter', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'california', '90815', 'Park  Avenue', 'Atherton Street', 'For Regular Check Up', '2000-12-13', 'hhh', 11126, '2014-12-16', '02:00:00'),
(11130, 'Nishita Avalani', 'harshal_shah93@yahoo.com', '5625072049', 'Irvine', 'California', '37589', 'Mc Villiam Strret', '', 'Appointment for stomach problem', '1993-03-13', 'hhh', 11130, '2014-12-24', '06:00:00'),
(11131, 'Neil Thaker', 'harshal_shah93@yahoo.com', '5625072049', 'Irvine', 'California', '49856', 'Mc Villiam Strret', '', 'Appointment for full body check up.', '2000-05-07', 'hhh', 11131, '2014-02-28', '04:00:00'),
(11132, 'Manan Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Los Angeles', 'California', '34564', 'Mc Villiam Strret', '', 'Appointments for check up', '1996-09-25', 'hhh', 11132, '2014-01-16', '05:00:00'),
(11133, 'Khyati Vora', 'harshal_shah93@yahoo.com', '5625072049', 'Irvine', 'California', '45673', 'Atherton street', '', 'Appointment for check up.', '1986-09-18', 'hhh', 11133, '2014-12-26', '01:00:00'),
(11140, 'Parin Choksi', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '34563', 'Atherton street', '', 'Appointment for routine check up', '2014-04-18', 'hhh', 11140, '2015-04-16', '05:00:00'),
(11141, 'Sidhdharth Shah', 'harshal_shah93@yahoo.com', '5625072049', 'Buffalo', 'NewYork', '87764', 'Clark Avenue', '', 'Appointment for headache', '1996-07-19', 'hhh', 11141, '2014-03-14', '04:00:00'),
(11142, 'Shradhdha Shah', 'harshal_shah93@yahoo.com', '5625072049', 'San Diego', 'California', '65334', 'Mc Villiam Strret', '', 'Appointment for check up', '1997-11-21', 'hhh', 11142, '2014-02-13', '02:00:00'),
(11144, 'Komal Gohel', 'harshal_shah93@yahoo.com', '5625072049', 'Houston', 'Texas', '45634', 'Garford Street', '', 'Appointment for check up', '1996-06-20', 'hhh', 11144, '2014-08-21', '02:00:00'),
(11145, 'Kuntal Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '90815', 'Garford Street', '', 'Appointment for check in.', '1994-08-14', 'hhh', 11145, '2014-01-22', '03:00:00'),
(11150, 'Shishir Shah', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '', 'Garford Street', '', 'Appointment for check in.', '2001-11-10', 'hhh', 11150, '2014-02-03', '04:00:00'),
(11151, 'Bhavik shah', 'harshal_shah93@yahoo.com', '5625072049', 'Long Beach', 'California', '90815', 'Garford Street', '', 'Appointment for check in.', '2001-12-19', 'hhh', 11151, '2014-05-21', '06:00:00'),
(11152, 'Darshan Bagadiya', 'harshal_shah93@yahoo.com', '5625072049', 'Los Angeles', 'California', '34564', 'Clark Avenue', '', 'appointment for skin allergies', '2014-01-29', '-', 11152, '2014-02-12', '04:00:00'),
(11153, 'Aneri Parikh', 'harshal_shah93@yahoo.com', '5625072049', 'Irvine', 'California', '34556', 'Atherton street', '', 'Appointment for check in', '2002-01-04', '-', 11153, '2014-03-20', '02:00:00'),
(11158, 'Harshil Pathak', 'harshal_shah93@yahoo.com', '5625072049', 'Buffalo', 'NewYork', '45647', 'willow Street', '', 'Appointment for Dentistry', '1995-09-23', '-', 11158, '2014-02-21', '03:00:00'),
(11161, 'Utkarsh Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Houston', 'Texas', '34535', 'Atherton street', '', 'Appointment for regular check up', '2007-11-20', '-', 11161, '2014-04-17', '03:00:00'),
(11162, 'Deep Doshi', 'harshal_shah93@yahoo.com', '5625072049', 'Fullerton', 'California', '35467', 'Garford Street', '', 'appointment for headache', '2008-07-24', '-', 11162, '2014-08-14', '05:00:00'),
(11163, 'Henny Doshi', 'harshal_shah93@yahoo.com', '5625072049', 'Houston', 'Texas', '43555', 'willow Street', '', 'Appointment for headache', '2009-02-27', '-', 11163, '2014-06-19', '03:00:00'),
(11164, 'Ridhdhi Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Buffalo', 'NewYork', '34664', 'Mc Villiam Strret', '', 'Appointment for headache', '2014-10-09', '-', 11164, '2014-03-18', '05:00:00'),
(11167, 'Hemagi Chaudhary', 'harshal_shah93@yahoo.com', '5625072049', 'San Diego', 'California', '34858', 'Garford Street', '', 'Appointment for routine check up.', '2014-06-10', 'hhh', 11167, '2014-10-17', '05:00:00'),
(11171, 'Meet Doshi', 'harshal_shah93@yahoo.com', '5625072049', 'Houston', 'Texas', '45645', 'Mc Villiam Strret', '', 'appointment for check up', '2008-07-17', '-', 11171, '2014-12-15', '03:00:00'),
(11172, 'Parth Patel', 'harshal_shah93@yahoo.com', '5625072049', 'Irvine', 'California', '34556', 'Clark Avenue', '', 'appointment for headche', '2000-01-14', '-', 11172, '2014-05-23', '06:00:00'),
(13224, 'Jaynil Shah', 'harshal_shah93@yahoo.com', '5625072049', 'Buffalo', 'NewYork', '56789', 'Mc Villiam Strret', '', 'Appointment for regular check up', '2014-11-01', 'hhh', 13224, '2014-09-19', '06:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mailview`
--

CREATE TABLE IF NOT EXISTS `mailview` (
  `name` varchar(1000) NOT NULL,
  `subject` varchar(1000) NOT NULL,
  `body` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mailview`
--

INSERT INTO `mailview` (`name`, `subject`, `body`) VALUES
('Feedback', 'Visit Feedback', 'Give feedback about your Visit here.'),
('Announcement', 'General Message', 'This message is about.....'),
('Appointment Reminder', 'Visit Appointment Reminder', 'Your appointment for {reason} is scheduled on this {day} at this {time}.'),
('Wish Happy Birthday', 'Happy Birthday!!!', 'University Health System Wish you a many many happy returns of the day!!!Enjoy.Have a great year ahead.');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `name` varchar(5000) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`name`, `date`) VALUES
('this is news 10', '2014-11-20 12:31:06'),
('this is news 9', '2014-11-20 12:31:01'),
('this is news 8', '2014-11-20 12:30:55'),
('this is news 7', '2014-11-20 12:30:49'),
('this is news 6', '2014-11-20 12:30:43'),
('this is news 5', '2014-11-20 12:30:37'),
('this is news 4\r\n', '2014-11-20 12:30:21'),
('this is news3\r\n', '2014-11-20 12:30:14'),
('this is news 2', '2014-11-20 12:29:43'),
('this is news 1', '2014-11-20 12:29:34'),
('Today is holiday.', '2014-12-02 10:48:31');

-- --------------------------------------------------------

--
-- Table structure for table `querytable`
--

CREATE TABLE IF NOT EXISTS `querytable` (
  `query` varchar(1000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `criteria` varchar(1000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `querytable`
--

INSERT INTO `querytable` (`query`, `name`, `criteria`) VALUES
(' SELECT * from appscheduler_bookings where MONTH(appointment_d)=12;', 'December Appointment', ' Appointment in Month 12'),
(' SELECT * from appscheduler_bookings where MONTH(student_dob)=5;', 'May Birthday', ' Appointment whose Birth Month is 5');

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE IF NOT EXISTS `usertable` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`username`, `password`) VALUES
('admin', 'admin');
